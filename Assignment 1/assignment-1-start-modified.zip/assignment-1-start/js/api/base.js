// replace your api key 
const API_KEY = "YOUR API KEY"

// create getWeather function here

// export the getWeather function