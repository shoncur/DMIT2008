# Assignment 1

Read the PDF Attached.
