# Assignment 1

Read the PDF Attached.

Notes for creating the assignment:
- Create package.json using `npm init`
- Install parcel to dev dependencies using `npm install parcel --save-dev`
- Install bootstrap to dependencies using `npm install bootstrap`