# Assignment 2 Starter

## Getting Started

1. install all of the dependencies of the project.

```bash
npm install
```

2. run the development server:

```bash
npm run dev
# or
yarn dev
```

Open [http://localhost:3000](http://localhost:3000) to browse the project.
