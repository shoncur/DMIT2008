const BASE_URL = "https://lldev.thespacedevs.com/2.2.0"

export { BASE_URL }