import {useRouter} from 'next/router'

import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import NavBar from '@components/NavBar';

export default function Agency() {
    const router = useRouter()
    const {id} = router.query

    return <>
        <NavBar />
        <Container sx={{paddingTop:2}} component="main">
            <Typography variant="h3">
                Agency {id}
            </Typography>
        </Container>
    </>
}